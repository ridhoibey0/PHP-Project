# TeamProfile

Team Profile yang saya kerjakan untuk UKK (Ujian Kenaikan Kelas) pada saat di kelas XI RPL

Menggunakan Bootstrap, HTML, dan CSS

![image](https://user-images.githubusercontent.com/39010800/135810295-6c9f7b28-4ef1-4a16-a65d-4bad3229cc4d.png)


#Hacktoberfest2021

