# Zall-Blogx
Zall-Blogx adalah template blog serbaguna yang dibuat menggunakan framework Bootstrap, HTML, dan Javascript sederhana.
![image](https://user-images.githubusercontent.com/46246652/135799012-59a0ec54-5e48-44c2-a74b-243f839d0334.png)

#Hacktoberfest2021
